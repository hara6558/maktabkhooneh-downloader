[app]
title = Maktabkhooneh Downloader
package.name = maktabkhoonehdownloader
package.domain = org.maktabkhooneh
source.dir = .
source.include_exts = py,kv,json,png,jpg
version = 1.0
requirements = python3,kivy,requests
orientation = portrait
fullscreen = 0
android.api = 35
android.minapi = 26
android.archs = arm64-v8a, armeabi-v7a
android.permissions = INTERNET,POST_NOTIFICATIONS
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
