import os,re,json,threading,requests
from urllib.parse import urlparse
from kivy.app import App
from kivy.lang import Builder
from kivy.clock import Clock
from kivy.properties import StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.checkbox import CheckBox

BASE='https://maktabkhooneh.org'

KV=r'''
BoxLayout:
    orientation:'vertical'
    padding:dp(8); spacing:dp(6)
    Label:
        text:'دانلودر مکتب‌خونه — نسخه اندروید'
        size_hint_y:None; height:dp(42); font_size:'20sp'
    TextInput:
        id:email; hint_text:'ایمیل'; multiline:False; text:app.email; size_hint_y:None; height:dp(40)
    TextInput:
        id:password; hint_text:'رمز عبور'; password:True; multiline:False; text:app.password; size_hint_y:None; height:dp(40)
    TextInput:
        id:url; hint_text:'لینک دوره'; multiline:False; size_hint_y:None; height:dp(40)
    BoxLayout:
        size_hint_y:None; height:dp(40); spacing:dp(5)
        Button: text:'ورود'; on_release:app.login()
        Button: text:'دریافت دوره'; on_release:app.load_course()
    BoxLayout:
        size_hint_y:None; height:dp(40); spacing:dp(5)
        Spinner:
            id:quality; text:'بهترین کیفیت'; values:['بهترین کیفیت','1080p','720p','480p','360p']
        Spinner:
            id:kind; text:'ویدئو'; values:['ویدئو','صوت (MP3)']
    ScrollView:
        GridLayout:
            id:list; cols:1; spacing:dp(3); size_hint_y:None; height:self.minimum_height
    BoxLayout:
        size_hint_y:None; height:dp(42); spacing:dp(5)
        Button: text:'انتخاب همه'; on_release:app.select_all(True)
        Button: text:'لغو همه'; on_release:app.select_all(False)
        Button: text:'دانلود'; on_release:app.download_selected()
    Label:
        text:app.status; text_size:self.width,None; halign:'right'; size_hint_y:None; height:dp(48)
'''

class AppMain(App):
    status=StringProperty('آماده')
    email=StringProperty(''); password=StringProperty('')
    session=None; units=[]; stop_flag=False

    def build(self):
        self.title='Maktabkhooneh Downloader'; self.load_settings(); return Builder.load_string(KV)
    def settings_file(self): return os.path.join(self.user_data_dir,'settings.json')
    def load_settings(self):
        try:
            d=json.load(open(self.settings_file(),encoding='utf-8')); self.email=d.get('email',''); self.password=d.get('password','')
        except: pass
    def save_settings(self):
        os.makedirs(self.user_data_dir,exist_ok=True)
        json.dump({'email':self.root.ids.email.text,'password':self.root.ids.password.text},open(self.settings_file(),'w',encoding='utf-8'),ensure_ascii=False)
    def set_status(self,s): Clock.schedule_once(lambda dt:setattr(self,'status',s))
    def headers(self,referer=None): return {'User-Agent':'Mozilla/5.0','Referer':referer or BASE+'/','Accept':'application/json, text/plain, */*'}
    def csrf(self):
        r=self.session.get(BASE+'/api/v1/general/core-data/?profile=1',headers=self.headers(),timeout=30); r.raise_for_status()
        return r.cookies.get('csrftoken') or self.session.cookies.get('csrftoken')
    def login(self): threading.Thread(target=self._login,daemon=True).start()
    def _login(self):
        try:
            self.session=requests.Session(); csrf=self.csrf(); h=self.headers(); h['X-CSRFToken']=csrf
            e=self.root.ids.email.text.strip(); p=self.root.ids.password.text
            r=self.session.post(BASE+'/api/v1/auth/check-active-user',data={'email':e,'csrfmiddlewaretoken':csrf,'tessera':'','g-recaptcha-response':''},headers=h,timeout=30); r.raise_for_status()
            d=r.json()
            if d.get('status') not in ('success',True): raise Exception(d.get('message','احراز اولیه ناموفق بود'))
            r=self.session.post(BASE+'/api/v1/auth/login-authentication',data={'email':e,'password':p,'csrfmiddlewaretoken':csrf,'tessera':''},headers=h,timeout=30); r.raise_for_status()
            if not self.session.cookies.get('sessionid'): raise Exception('نشست ورود دریافت نشد.')
            self.save_settings(); self.set_status('ورود با موفقیت انجام شد.')
        except Exception as ex: self.set_status('خطا: '+str(ex))
    def slug(self,u):
        parts=[x for x in urlparse(u.strip()).path.split('/') if x]
        for i,x in enumerate(parts[:-1]):
            if x in ('course',) and i+1<len(parts): return parts[i+1]
        raise Exception('لینک دوره معتبر نیست.')
    def course_id(self,slug):
        m=re.search(r'-mk(\d+)$',slug,re.I); return m.group(1) if m else None
    def load_course(self): threading.Thread(target=self._load_course,daemon=True).start()
    def _load_course(self):
        try:
            if not self.session:self.session=requests.Session()
            u=self.root.ids.url.text.strip(); slug=self.slug(u); cid=self.course_id(slug); data=None
            if cid:
                r=self.session.get(BASE+f'/api/v1/lms/courses/{cid}/outline/',headers=self.headers(u),timeout=35)
                if r.ok:
                    try:data=r.json()
                    except:pass
            if not data:
                r=self.session.get(BASE+f'/api/v1/courses/{slug}/chapters/',headers=self.headers(u),timeout=35); r.raise_for_status(); data=r.json()
            chapters=data.get('chapters',[]) if isinstance(data,dict) else []
            if not chapters and isinstance(data,dict): chapters=data.get('results') or data.get('children') or []
            rows=[]
            for ci,ch in enumerate(chapters,1):
                us=ch.get('units') if isinstance(ch,dict) else None
                if not isinstance(us,list): us=ch.get('unit_set',[]) if isinstance(ch,dict) else []
                for ui,x in enumerate(us,1):
                    if isinstance(x,dict) and (x.get('type') in (1,'lecture') or x.get('type') is None):
                        rows.append((ci,ui,ch.get('title',''),x))
            Clock.schedule_once(lambda dt:self.show_units(rows)); self.set_status(f'{len(rows)} درس پیدا شد.')
        except Exception as ex:self.set_status('خطا در دریافت دوره: '+str(ex))
    def show_units(self,rows):
        box=self.root.ids.list; box.clear_widgets(); self.units=[]
        for ci,ui,ch,u in rows:
            cb=CheckBox(size_hint_x=None,width=dp(42)); title=u.get('title') or u.get('slug') or 'درس'
            lab=Label(text=f'پارت {ci:02d} | بخش {ui:02d} | {title}',halign='right',text_size=(None,None))
            row=BoxLayout(size_hint_y=None,height=dp(40)); row.add_widget(cb); row.add_widget(lab); box.add_widget(row); self.units.append((cb,ci,ui,ch,u))
    def select_all(self,v):
        for x in self.units:x[0].active=v
    def download_selected(self):
        sel=[x for x in self.units if x[0].active]
        if not sel:return self.set_status('هیچ بخشی انتخاب نشده است.')
        self.stop_flag=False; threading.Thread(target=self._download,args=(sel,),daemon=True).start()
    def video_data(self,uid,ref):
        r=self.session.get(BASE+f'/api/v1/lms/units/{uid}/video_url/',headers=self.headers(ref),timeout=35); r.raise_for_status(); return r.json()
    def unit_data(self,uid,ref):
        r=self.session.get(BASE+f'/api/v1/lms/units/{uid}/',headers=self.headers(ref),timeout=35); r.raise_for_status(); return r.json()
    def choose_quality(self,d):
        qs=d.get('qualities',[]) if isinstance(d,dict) else []
        if not qs:
            v=d.get('video_urls',{}) if isinstance(d,dict) else {}; return v.get('hq') or v.get('lq'),None
        q=self.root.ids.quality.text
        def res(x):
            try:return int(x.get('resolution') or re.sub(r'\D','',str(x.get('quality',''))) or 0)
            except:return 0
        if q=='بهترین کیفیت': cand=sorted(qs,key=res,reverse=True)
        else:
            n=int(q[:-1]); cand=sorted(qs,key=lambda x:abs(res(x)-n*1),reverse=False)
            exact=[x for x in cand if res(x)==n]
            if exact:cand=exact+cand
        for x in cand:
            if x.get('download_url'):return x['download_url'],res(x)
        return None,None
    def filename(self,s): return re.sub(r'[\\/:*?"<>|]+','_',s).strip() or 'file'
    def download_file(self,url,path,ref,progress_label):
        tmp=path+'.part'; done=os.path.getsize(tmp) if os.path.exists(tmp) else 0
        headers=self.headers(ref)
        if done: headers['Range']=f'bytes={done}-'
        r=self.session.get(url,headers=headers,stream=True,timeout=90)
        if done and r.status_code!=206: done=0; r.close(); r=self.session.get(url,headers=self.headers(ref),stream=True,timeout=90)
        r.raise_for_status(); total=int(r.headers.get('content-length',0))+done; cur=done
        with open(tmp,'ab' if done else 'wb') as f:
            for c in r.iter_content(1024*512):
                if self.stop_flag: break
                if c:
                    f.write(c);cur+=len(c)
                    pct=int(cur*100/total) if total else 0; self.set_status(f'{progress_label} — {pct}%')
        if self.stop_flag:return False
        os.replace(tmp,path);return True
    def _download(self,sel):
        root=os.path.join(self.user_data_dir,'Downloads');os.makedirs(root,exist_ok=True); ref=self.root.ids.url.text.strip(); mode=self.root.ids.kind.text
        for n,(cb,ci,ui,ch,u) in enumerate(sel,1):
            try:
                uid=u.get('id') or u.get('unit_id'); title=self.filename(u.get('title') or u.get('slug') or f'بخش {ui:02d}')
                vd=self.video_data(uid,ref); src,res=self.choose_quality(vd)
                if not src: raise Exception('آدرس ویدئو پیدا نشد.')
                ext='.mp4'
                if 'MP3' in mode:
                    # only use a real direct audio URL if API exposes one; never fake an MP3 by renaming video
                    for k in ('audio_url','audio_download_url'):
                        if isinstance(vd,dict) and vd.get(k): src=vd[k]; ext='.mp3'; break
                    else: raise Exception('برای MP3، API آدرس صوت مستقیم نداده است؛ تبدیل واقعی با FFmpeg در این نسخه فعال نیست.')
                base=f'پارت {ci:02d} - بخش {ui:02d} - {title}'
                path=os.path.join(root,base+ext); self.download_file(src,path,ref,f'{n}/{len(sel)} {title}')
                try:
                    ud=self.unit_data(uid,ref); cap=ud.get('caption_file') if ud.get('has_caption') else None
                    if cap:
                        sp=os.path.join(root,base+'.vtt'); self.download_file(cap,sp,ref,'زیرنویس '+title)
                    for rr in ud.get('resources',[]) if isinstance(ud,dict) else []:
                        au=rr.get('download_url');
                        if not au or rr.get('type')==1: continue
                        name=self.filename(os.path.basename(urlparse(au).path) or 'resource.bin'); self.download_file(au,os.path.join(root,base+' - '+name),ref,'فایل '+title)
                except Exception as rex:self.set_status('فایل جانبی رد شد: '+str(rex))
            except Exception as ex:self.set_status(f'خطا در {title}: {ex}')
        self.set_status('دانلودهای انتخاب‌شده پایان یافت. مسیر ذخیره داخل پوشه برنامه است.')

if __name__=='__main__': AppMain().run()
